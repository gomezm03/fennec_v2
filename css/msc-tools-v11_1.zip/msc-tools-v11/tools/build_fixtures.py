#!/usr/bin/env python3
"""Builds the JSON fixtures in data/ and the file:// fallback bundle data/fixtures.js.
Run from the repo root:  python3 tools/build_fixtures.py
All values are fictional stand-ins in realistic formats (README section 10)."""
import json, os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, 'data')
os.makedirs(DATA, exist_ok=True)

def P(sku, brand, title, kind, coat, coatName, price, stock, lead, desc,
      diaDec, dia, fl, loc, locDec, shank, oal, helix, series, **extra):
    d = dict(sku=sku, brand=brand, title=title, kind=kind, coat=coat, coatName=coatName,
             price=price, stock=stock, lead=lead, desc=desc, diaDec=diaDec, dia=dia, fl=fl,
             loc=loc, locDec=locDec, shank=shank, oal=oal, helix=helix, series=series,
             mfr=f"{series}-{sku[-4:]}")
    d.update(extra)
    return d

products = [
 P('09990412','Accupro','1/2" 4-Flute Carbide Square End Mill — AlTiN','endmill','altin','AlTiN',84.12,143,'Next day',
   '3" OAL, 1/2" shank dia, 38° helix, AlTiN coated, single end, centercutting',.5,'1/2','4','1-1/4',1.25,'1/2','3','38°','ACC4-SQ'),
 P('09990627','Hertel','1/2" 4-Flute Carbide Square End Mill — TiAlN','endmill','tialn','TiAlN',61.30,88,'Next day',
   '2-1/2" OAL, 1/2" shank dia, 35° helix, TiAlN coated, single end, centercutting',.5,'1/2','4','1',1.0,'1/2','2-1/2','35°','HTL-GP4'),
 P('09990981','OSG','1/2" 5-Flute Carbide End Mill — Bright','endmill','bright','Bright/Uncoated',97.45,12,'2-day',
   '3" OAL, 1/2" shank dia, variable 45° helix, .015" corner radius, single end',.5,'1/2','5','1-1/4',1.25,'1/2','3','45° variable','VGM5', radius='.015'),
 P('09991172','Niagara','1/2" 4-Flute Square End Mill — TiCN','endmill','ticn','TiCN',71.88,51,'Next day',
   '3" OAL, 1/2" shank dia, 30° helix, TiCN coated, single end, centercutting',.5,'1/2','4','1-1/4',1.25,'1/2','3','30°','N85907'),
 P('09990455','Accupro','1/4" 3-Flute Carbide End Mill — ZrN','endmill','zrn','ZrN',41.05,210,'Next day',
   '2-1/2" OAL, 1/4" shank dia, 40° helix, ZrN coated aluminum-spec geometry, single end',.25,'1/4','3','3/4',.75,'1/4','2-1/2','40°','ACC3-AL'),
 P('09990118','Hertel','#7 (.201") Carbide Jobber Drill — TiN','drill','tin','TiN',38.91,96,'Next day',
   '3.6" OAL, 118° point, right hand spiral flute, TiN coated',.201,'#7 (.201)','2','2.16 flute',2.16,'.201','3.6','118° point','HTL-JD'),
 P('09990904','OSG','#7 (.201") Carbide Drill — Bright','drill','bright','Bright/Uncoated',52.10,33,'Next day',
   '3.5" OAL, 140° point, coolant-through, right hand spiral',.201,'#7 (.201)','2','2.0 flute',2.0,'.201','3.5','140° point','EXO-DRL'),
 P('09991177','Niagara','3/4" 4-Flute Carbide Rougher — TiCN','endmill','ticn','TiCN',60.30,27,'Next day',
   '4" OAL, 3/4" shank dia, corncob chipbreaker profile, single end',.75,'3/4','4','1-1/2',1.5,'3/4','4','35°','NRC4'),
 P('09990619','Accupro','3/4" 4-Flute Carbide End Mill — AlTiN','endmill','altin','AlTiN',78.12,44,'Next day',
   '4" OAL, 3/4" shank dia, 38° helix, AlTiN coated, single end, centercutting',.75,'3/4','4','1-1/2',1.5,'3/4','4','38°','ACC4-SQ'),
 P('09990101','Hertel','1/4" Jobber Length Drill — TiN','drill','tin','TiN',12.40,340,'Next day',
   '4" OAL, 118° point, right hand spiral flute, TiN coated HSS',.25,'1/4','2','2.75 flute',2.75,'1/4','4','118° point','HTL-JD', material='High Speed Steel'),
 P('09990233','Accupro','90° 4-Flute Carbide Chamfer Mill — AlTiN','chamfer','altin','AlTiN',54.20,58,'Next day',
   '2-1/2" OAL, 1/2" shank dia, 90° included angle, AlTiN coated',.5,'1/2','4','1/4',.25,'1/2','2-1/2','90° incl.','ACC-CHM'),
 P('09990840','Accupro','3/8" 2-Flute Carbide Ball End Mill — AlTiN','ball','altin','AlTiN',47.75,71,'Next day',
   '2-1/2" OAL, 3/8" shank dia, 30° helix, ball nose, AlTiN coated, single end',.375,'3/8','2','1',1.0,'3/8','2-1/2','30°','ACC2-BN'),
]

# the "see all" long tail — 1/2" end mills in the same size class
more = [
 ('SGS','09991104','1/2" 3FL Alum-spec End Mill — ZrN',72.88,'zrn','ZrN','3','SGS-Z3'),
 ('Kennametal','09991245','1/2" 4FL HARVI I TE — AlTiN',118.60,'altin','AlTiN','4','HARVI-TE'),
 ('Accupro','09991301','1/2" 2FL Carbide End Mill — Uncoated',48.95,'bright','Bright/Uncoated','2','ACC2-SQ'),
 ('Hertel','09991377','1/2" 4FL Long-reach End Mill — TiAlN',79.40,'tialn','TiAlN','4','HTL-LR4'),
 ('OSG','09991420','1/2" 4FL Corner-radius .030 — Bright',102.15,'bright','Bright/Uncoated','4','OSG-CR4'),
 ('Niagara','09991488','1/2" 6FL Finisher — AlTiN',94.70,'altin','AlTiN','6','N-FIN6'),
 ('SGS','09991512','1/2" 3FL High-helix — Ti-Namite',81.25,'tin','Ti-Namite','3','SGS-HH3'),
 ('Accupro','09991590','1/2" 4FL Stub-length — AlTiN',69.85,'altin','AlTiN','4','ACC4-ST'),
 ('Kennametal','09991633','1/2" 4FL GOmill GP — TiAlN',88.30,'tialn','TiAlN','4','GOMILL-GP'),
 ('Hertel','09991701','1/2" 4FL Roughing (corncob) — Bright',74.60,'bright','Bright/Uncoated','4','HTL-RGH'),
 ('OSG','09991766','1/2" 4FL Variable-index — EXOCARB',109.90,'altin','AlTiN','4','EXOCARB-VI'),
]
for b,s,n,p,c,cn,fl,series in more:
    products.append(P(s,b,n,'endmill',c,cn,p,20+int(s[-2:]),'Next day',
        '3" OAL, 1/2" shank dia, solid carbide, single end, centercutting',.5,'1/2',fl,'1-1/4',1.25,'1/2','3','38°',series))


# tool-first advisor: drills, taps, chamfer mills, ball end mills per material group
products += [
 P('09990125','Accupro','1/4" Carbide Jobber Drill — AlTiN','drill','altin','AlTiN',34.60,120,'Next day',
   '3.4" OAL, 140° split point, right hand spiral flute, AlTiN coated',.25,'1/4','2','2.5 flute',2.5,'1/4','3.4','140° point','ACC-JD'),
 P('09990133','Kennametal','1/4" Carbide Drill — Coolant-through, TiAlN','drill','tialn','TiAlN',58.20,36,'Next day',
   '3.6" OAL, 140° point, coolant-through, 5×D, TiAlN coated',.25,'1/4','2','2.5 flute',2.5,'1/4','3.6','140° point','KEN-CT5', coolant=True),
 P('09990140','SGS','1/4" Carbide Drill — Polished, aluminum-spec','drill','bright','Bright/Polished',41.75,64,'Next day',
   '3.4" OAL, 130° point, polished flutes for aluminum, right hand spiral',.25,'1/4','2','2.5 flute',2.5,'1/4','3.4','130° point','SGS-AL'),
 P('09990301','Accupro','3/8-16 UNC Spiral Flute Tap — TiN','tap','tin','TiN',22.40,180,'Next day',
   'Spiral flute, bottoming chamfer, H3 limit, TiN coated HSS-E, for blind holes',.375,'3/8-16','3','1-1/8',1.125,'.381','2-15/16','35° spiral','ACC-SF', tpi=16, thread='3/8-16 UNC', tapStyle='Spiral flute', chamferType='Bottoming', material='HSS-E'),
 P('09990308','OSG','3/8-16 UNC Spiral Point Tap — Bright','tap','bright','Bright/Uncoated',19.85,140,'Next day',
   'Spiral point (gun), plug chamfer, H3 limit, HSS-E, for through holes',.375,'3/8-16','3','1-1/8',1.125,'.381','2-15/16','Spiral point','OSG-SP', tpi=16, thread='3/8-16 UNC', tapStyle='Spiral point', chamferType='Plug', material='HSS-E'),
 P('09990315','Hertel','3/8-16 UNC Forming Tap — TiCN','tap','ticn','TiCN',27.10,75,'Next day',
   'Thread forming (roll) tap, no chips, H5 limit, TiCN coated HSS-E, for aluminum and ductile steels',.375,'3/8-16','—','1-1/8',1.125,'.381','2-15/16','Form','HTL-FT', tpi=16, thread='3/8-16 UNC', tapStyle='Forming', chamferType='Bottoming', material='HSS-E'),
 P('09990322','Kennametal','3/8-16 UNC Spiral Flute Tap — Stainless, TiAlN','tap','tialn','TiAlN',34.90,48,'Next day',
   'Spiral flute, bottoming chamfer, H3 limit, TiAlN coated powder-metal HSS, for stainless and superalloys',.375,'3/8-16','3','1-1/8',1.125,'.381','2-15/16','40° spiral','KEN-SS', tpi=16, thread='3/8-16 UNC', tapStyle='Spiral flute', chamferType='Bottoming', material='PM-HSS'),
 P('09990160','Hertel','5/16" (.3125") Tap Drill for 3/8-16 — TiN','drill','tin','TiN',16.80,150,'Next day',
   '4.5" OAL, 118° point, jobber length, TiN coated HSS, tap drill for 3/8-16 UNC',.3125,'5/16','2','3.0 flute',3.0,'5/16','4.5','118° point','HTL-TD', material='High Speed Steel'),
 P('09990240','Hertel','90° 3-Flute Carbide Chamfer Mill — Bright','chamfer','bright','Bright/Uncoated',44.60,90,'Next day',
   '2-1/2" OAL, 1/2" shank dia, 90° included angle, polished flutes for aluminum',.5,'1/2','3','1/4',.25,'1/2','2-1/2','90° incl.','HTL-CHM'),
 P('09990247','OSG','60° 4-Flute Carbide Chamfer Mill — AlTiN','chamfer','altin','AlTiN',61.30,38,'Next day',
   '2-1/2" OAL, 1/2" shank dia, 60° included angle, AlTiN coated',.5,'1/2','4','5/16',.3125,'1/2','2-1/2','60° incl.','OSG-CH60'),
 P('09990847','Accupro','1/2" 2-Flute Carbide Ball End Mill — ZrN','ball','zrn','ZrN',52.80,66,'Next day',
   '3" OAL, 1/2" shank dia, 30° helix, ball nose, ZrN coated aluminum-spec, single end',.5,'1/2','2','1-1/4',1.25,'1/2','3','30°','ACC2-BN-AL'),
 P('09990854','Niagara','1/2" 4-Flute Carbide Ball End Mill — AlTiN','ball','altin','AlTiN',74.20,42,'Next day',
   '3" OAL, 1/2" shank dia, 30° helix, ball nose, AlTiN coated, single end',.5,'1/2','4','1-1/4',1.25,'1/2','3','30°','N-BN4'),
]

# accessories for "Often bought with"
acc = [
 dict(sku='09995001',brand='Accupro',title='CAT40 ER32 Collet Chuck — 4" Projection',kind='holder',coat='bright',coatName='—',price=129.00,stock=64,lead='Next day',
      desc='CAT40 taper, ER32 collet system, 4" projection, balanced to G2.5 at 20,000 RPM',series='ACC-CAT40-ER32',mfr='ACC-CAT40-ER32-4',
      specs=[('Taper','CAT40'),('Collet System','ER32'),('Projection','4"'),('Balance','G2.5 @ 20,000 RPM'),('Coolant','Through spindle'),('Material','Alloy steel, hardened')]),
 dict(sku='09995012',brand='Accupro',title='ER32 Collet — 1/2" Capacity',kind='collet',coat='bright',coatName='—',price=18.40,stock=220,lead='Next day',
      desc='ER32 precision collet, 1/2" nominal, .0002" TIR, spring steel',series='ACC-ER32',mfr='ACC-ER32-500',
      specs=[('Collet Series','ER32'),('Nominal Size','1/2"'),('Clamping Range','.472" – .512"'),('Runout','.0002" TIR'),('Material','Spring steel')]),
 dict(sku='09995013',brand='Accupro',title='ER32 Collet — 1/4" Capacity',kind='collet',coat='bright',coatName='—',price=18.40,stock=180,lead='Next day',
      desc='ER32 precision collet, 1/4" nominal, .0002" TIR, spring steel',series='ACC-ER32',mfr='ACC-ER32-250',
      specs=[('Collet Series','ER32'),('Nominal Size','1/4"'),('Clamping Range','.236" – .276"'),('Runout','.0002" TIR'),('Material','Spring steel')]),
 dict(sku='09995014',brand='Accupro',title='ER32 Collet — 3/8" Capacity',kind='collet',coat='bright',coatName='—',price=18.40,stock=150,lead='Next day',
      desc='ER32 precision collet, 3/8" nominal, .0002" TIR, spring steel',series='ACC-ER32',mfr='ACC-ER32-375',
      specs=[('Collet Series','ER32'),('Nominal Size','3/8"'),('Clamping Range','.354" – .394"'),('Runout','.0002" TIR'),('Material','Spring steel')]),
 dict(sku='09995015',brand='Accupro',title='ER32 Collet — 3/4" Capacity',kind='collet',coat='bright',coatName='—',price=18.40,stock=120,lead='Next day',
      desc='ER32 precision collet, 3/4" nominal, .0002" TIR, spring steel',series='ACC-ER32',mfr='ACC-ER32-750',
      specs=[('Collet Series','ER32'),('Nominal Size','3/4"'),('Clamping Range','.709" – .749"'),('Runout','.0002" TIR'),('Material','Spring steel')]),
 dict(sku='09995100',brand='Hertel',title='Semi-synthetic Cutting Fluid — 5 Gal',kind='coolant',coat='bright',coatName='—',price=96.50,stock=41,lead='Next day',
      desc='General-purpose semi-synthetic, low foam, 5% – 8% concentration, ferrous and non-ferrous',series='HTL-CF',mfr='HTL-CF-5G',
      specs=[('Type','Semi-synthetic'),('Container','5 gal pail'),('Concentration','5% – 8%'),('Materials','Ferrous, aluminum, brass'),('Foam','Low')]),
]
products += acc

# related: accessories by shank size
often_with = {'3/8-16':['09990160','09995001','09995100'],'1/2':['09995001','09995012','09995100'],'1/4':['09995001','09995013','09995100'],
              '3/8':['09995001','09995014','09995100'],'3/4':['09995001','09995015','09995100'],
              '.201':['09995001','09995013','09995100']}

catalog = dict(
  total=127,
  resultSets={
    'endmill':{'N':[['09991104',96],['09991301',94],['09990981',92]],'P':[['09990412',96],['09990627',93],['09991172',90]],
               'M':[['09990412',95],['09990627',93],['09991488',91]],'K':[['09991172',94],['09990412',92],['09991701',89]],
               'S':[['09990412',93],['09990627',91],['09991512',89]],'H':[['09990412',92],['09991488',90],['09990627',88]]},
    'ball':{'N':[['09990847',96],['09990840',90]],'P':[['09990854',95],['09990840',92]],'M':[['09990854',94],['09990840',91]],
            'K':[['09990854',93],['09990840',90]],'S':[['09990854',92],['09990840',89]],'H':[['09990854',92],['09990840',88]]},
    'drill':{'N':[['09990140',96],['09990904',92],['09990101',85]],'P':[['09990125',96],['09990133',93],['09990118',90]],
             'M':[['09990133',95],['09990125',92],['09990118',88]],'K':[['09990125',94],['09990133',92],['09990118',89]],
             'S':[['09990133',95],['09990125',90],['09990904',86]],'H':[['09990133',93],['09990125',90],['09990904',85]]},
    'tap':{'N':[['09990315',96],['09990308',93],['09990301',90]],'P':[['09990301',96],['09990308',94],['09990315',89]],
           'M':[['09990322',96],['09990301',91],['09990308',88]],'K':[['09990308',95],['09990301',92],['09990322',88]],
           'S':[['09990322',96],['09990301',88],['09990308',84]],'H':[['09990322',93],['09990301',87],['09990308',82]]},
    'chamfer':{'N':[['09990240',96],['09990233',91],['09990247',88]],'P':[['09990233',96],['09990247',92],['09990240',86]],
               'M':[['09990233',95],['09990247',92],['09990240',84]],'K':[['09990233',94],['09990247',91],['09990240',86]],
               'S':[['09990247',94],['09990233',92],['09990240',80]],'H':[['09990233',93],['09990247',91],['09990240',80]]}},
  totals={'endmill':127,'ball':38,'drill':64,'tap':41,'chamfer':22},
  toolTypes=[
    dict(id='endmill', name='End mill', plural='end mills', sub='Pockets, profiles, slots, floors'),
    dict(id='ball', name='Ball end mill', plural='ball end mills', sub='3D contours, fillets'),
    dict(id='drill', name='Drill', plural='drills', sub='Holes, spot and pilot'),
    dict(id='tap', name='Tap', plural='taps', sub='Threaded holes'),
    dict(id='chamfer', name='Chamfer mill', plural='chamfer mills', sub='Edge breaks, countersinks')],
  # "Not sure — describe the feature": feature → recommended tool and defaults, with the reason shown to the user
  features=[
    dict(id='pocket', label='Pocket or profile', tool='endmill', end='square', why='Square end mill — flat floors and straight walls'),
    dict(id='slot', label='Slot', tool='endmill', end='square', fl='3', why='Square end mill with fewer flutes — room for chips in a full-width cut'),
    dict(id='floor', label='Floor or face finish', tool='endmill', end='square', fl='6', why='High-flute end mill — finer finish at the same feed'),
    dict(id='contour', label='3D contour or fillet', tool='ball', end='ball', why='Ball end mill — follows curved surfaces and inside radii'),
    dict(id='hole', label='Hole', tool='drill', why='Drill — size to the hole; add a reamer for tight tolerance'),
    dict(id='thread', label='Threaded hole', tool='tap', why='Tap — sized to the thread; the drill for the pilot hole is listed with it'),
    dict(id='edge', label='Edge break or countersink', tool='chamfer', why='Chamfer mill — one tool for edge breaks, countersinks and deburring')],
  # recommendations by material group, used when a geometry field is left blank
  recommend={
    'flutes':{'N':'3','P':'4','M':'4','K':'4','S':'5','H':'6'},
    'fluteWhy':{'N':'chip room for aluminum','P':'balance of rigidity and chip room for steel','M':'rigidity for stainless','K':'rigidity for cast iron','S':'more edges at low speed for superalloys','H':'more edges at low speed for hardened steel'},
    'tapStyle':{'blind':'Spiral flute','through':'Spiral point'},
    'tapStyleN':'Forming',
    'coolantDepth':3},
  moreSkus={'endmill':[s for _,s,*_ in more]},
  sfm={'N':900,'P':350,'M':240,'K':300,'S':120,'H':150},
  drillSfm={'N':300,'P':90,'M':70,'K':100,'S':40,'H':50},
  tapSfm={'N':60,'P':35,'M':20,'K':40,'S':10,'H':12},
  groupNames={'N':'Aluminum','P':'Steel','M':'Stainless','K':'Cast iron','S':'Superalloy / Ti','H':'Hardened'},
  groupPriority=['H','S','K','M','P','N'],
  oftenWith=often_with,
  products=products)

match = dict(
  reference=dict(pn='CM-2F340-0500-DEMO', maker='Sandvik-format part number', name='OEM 1/2" 4-Flute End Mill',
                 dia='.500', fl='4', loc='1.25', coat='AlTiN', price=142.55, lead='5-day'),
  fit={'09990412':96,'09990627':93,'09991172':90,'09990981':88,'09991420':87,'09991766':86,'09991245':85,
       '09991590':84,'09991488':83,'09991104':82,'09991512':81,'09991301':80,'09991633':79,'09991377':78,'09991701':77,'09990619':76},
  tops=['09990412','09990627','09991172','09990981'],
  pool=['09991420','09991766','09991245','09991590','09991488','09991104','09991512','09991301','09991633','09991377','09991701','09990619'])

cribs = [
 dict(name='Bay 2 — Haas VF-2', lines=[
   dict(sku='09990412', name='Accupro 1/2" 4FL End Mill', on=2, min=4, msc=True, price=84.12),
   dict(sku='09990101', name='Hertel 1/4" Jobber Drill — TiN', on=6, min=3, msc=True, price=12.40),
   dict(sku='X-77-0455', name='Legacy-brand 3/8-16 Spiral Tap', on=1, min=2, msc=False, price=0),
   dict(sku='09990233', name='Accupro 90° Chamfer Mill', on=5, min=2, msc=True, price=54.20)]),
 dict(name='Bay 1 — DMG Mori', lines=[
   dict(sku='09990627', name='Hertel 1/2" 4FL End Mill', on=3, min=3, msc=True, price=61.30),
   dict(sku='09990840', name='Accupro 3/8" Ball End Mill', on=1, min=3, msc=True, price=47.75),
   dict(sku='X-19-2210', name='Legacy-brand Spot Drill 120°', on=4, min=2, msc=False, price=0)]),
]

imports = dict(
 sample=dict(label='sample_tools.csv', rows=[
   dict(theirs='CM-2F340-0500', tname='OEM 1/2" 4FL end mill', tprice=89.40, alts=[dict(sku='09990412',fit=96),dict(sku='09990627',fit=93)]),
   dict(theirs='CM-1P330-0250', tname='OEM 1/4" 3FL end mill', tprice=64.15, alts=[dict(sku='09990455',fit=95)]),
   dict(theirs='DR-870-0201', tname='OEM #7 carbide drill', tprice=71.20, alts=[dict(sku='09990118',fit=94),dict(sku='09990904',fit=91)]),
   dict(theirs='TM-4F125-0750', tname='OEM 3/4" 4FL rougher', tprice=136.45, alts=[dict(sku='09991177',fit=92),dict(sku='09990619',fit=90)]),
   dict(theirs='CUSTOM-GRIND-77', tname='Custom form tool (shop grind)', tprice=None, unmatched=True)]),
 fusion=dict(label="this document's Fusion tool library", rows=[
   dict(theirs='T1 · GEN-EM-500-4F', tname='Generic 1/2" 4FL end mill · doc tool', tprice=96.00, alts=[dict(sku='09990412',fit=97),dict(sku='09990627',fit=94)]),
   dict(theirs='T2 · SUP-BN-375', tname='Supplier 3/8" ball nose · doc tool', tprice=44.10, alts=[dict(sku='09990840',fit=95)]),
   dict(theirs='T3 · GEN-DR-201', tname='Generic #7 drill · doc tool', tprice=61.75, alts=[dict(sku='09990118',fit=96),dict(sku='09990904',fit=92)]),
   dict(theirs='T4 · SUP-CH-90', tname='Supplier 90° chamfer mill · doc tool', tprice=71.30, alts=[dict(sku='09990233',fit=93)]),
   dict(theirs='T5 · GEN-EM-750-R', tname='Generic 3/4" rougher · doc tool', tprice=104.50, alts=[dict(sku='09991177',fit=91),dict(sku='09990619',fit=90)]),
   dict(theirs='T6 · CUSTOM-FORM-12', tname='Custom form tool · doc tool', tprice=None, unmatched=True)]))

files = {'catalog.json':catalog, 'match.json':match, 'cribs.json':cribs, 'imports.json':imports}
bundle = {}
for name, obj in files.items():
    with open(os.path.join(DATA, name), 'w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)
    bundle[name.split('.')[0]] = obj
with open(os.path.join(DATA, 'fixtures.js'), 'w', encoding='utf-8') as f:
    f.write('/* generated by tools/build_fixtures.py — used only when the app is opened from file:// (no fetch). */\n')
    f.write('window.MSC_FIXTURES = ' + json.dumps(bundle, ensure_ascii=False) + ';\n')
print('wrote', ', '.join(files), 'and fixtures.js —', len(products), 'products')
