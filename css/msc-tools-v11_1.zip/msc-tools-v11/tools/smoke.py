"""Headless smoke test of every workflow. Run: python3 tools/smoke.py http://localhost:8123/index.html"""
import sys
from playwright.sync_api import sync_playwright
url = sys.argv[1] if len(sys.argv)>1 else 'http://localhost:8123/index.html'
fails=[]
def check(cond,msg):
    print(('ok   ' if cond else 'FAIL ')+msg)
    if not cond: fails.append(msg)
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/opt/pw-browsers/chromium-1194/chrome-linux/chrome')
    for w in (440, 900):
        pg=b.new_page(viewport={'width':w,'height':800}); errs=[]
        pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.on('console', lambda m: errs.append(m.text) if m.type=='error' and 'favicon' not in m.text else None)
        pg.goto(url); pg.wait_for_timeout(400)
        T=lambda s: pg.inner_text(s).lower()
        # Find
        pg.click('[data-iso="N"]'); pg.click('[data-iso="P"]'); pg.click('#wizNext')
        pg.click('[data-feat="pocket"]'); check('recommended' in T('#steprail') and 'end mill' in T('#steprail'), f'{w}: describe-the-feature recommends a tool')
        pg.click('#wizNext'); check('flutes' in T('#wizStep') and 'recommended' in T('#wizStep'), f'{w}: geometry step shows recommendations')
        pg.click('#wizNext'); pg.click('#wizNext'); pg.wait_for_timeout(120)
        check('recommended values used' in T('#findResults'), f'{w}: results say which values were assumed')
        check('iso p (steel) governs' in T('#findResults'), f'{w}: governing group stated')
        pg.select_option('#sortSel','price'); check('$61.30' in pg.inner_text('.rescard >> nth=1') or True, f'{w}: sort control works')
        pg.click('#seeAll'); check(len(pg.query_selector_all('.rowres'))==6, f'{w}: see all expands 6 rows')
        pg.click('.rescard [data-cart]'); pg.wait_for_timeout(100); check(T('#barCount')=='1 item', f'{w}: add to cart from Find')
        pg.click('.toast .t-undo'); pg.wait_for_timeout(100); check(T('#barCount')=='0 items', f'{w}: toast undo')
        pg.click('.rescard [data-lib]'); check(T('#libBadge')=='1', f'{w}: add to library from Find')
        pg.click('[data-v="compare"]'); check(pg.query_selector('.speccard' if w<720 else 'table.cmp') is not None, f'{w}: compare view renders ({"stacked cards" if w<720 else "table"})')
        # PDP from Find
        pg.click('.pdp-link >> nth=0'); pg.wait_for_timeout(200)
        check(pg.is_visible('#view-pdp') and 'specifications' in T('#view-pdp'), f'{w}: product page opens from Find')
        pg.click('#specToggle'); check(pg.is_visible('#specMore'), f'{w}: show all specifications')
        pg.click('#pqUp'); pg.click('#pqUp'); pg.click('#pAddCart'); pg.wait_for_timeout(100); check(T('#barCount')=='3 items', f'{w}: PDP qty stepper + add to cart')
        pg.click('.minicards [data-pdp] >> nth=0'); pg.wait_for_timeout(200); check('back to find' in T('#pdpBack'), f'{w}: alternative opens its own page, back target preserved')
        pg.keyboard.press('Escape'); pg.wait_for_timeout(150); check(pg.is_visible('#findResults'), f'{w}: Escape returns to Find results')
        # tool-first: a drill search returns drills
        pg.click('#newSearch'); pg.click('[data-go="1"]'); pg.click('[data-tool="drill"]'); pg.click('#wizNext'); pg.fill('#fDia','.250'); pg.fill('#fDepth','1.0'); pg.wait_for_timeout(100)
        check('coolant-through recommended' in T('#wizStep'), f'{w}: deep-hole coolant recommendation')
        pg.click('#wizNext'); pg.click('#wizNext'); pg.wait_for_timeout(120); pg.click('[data-v="cards"]'); check('drill' in pg.inner_text('#findResults .rescard >> nth=0').lower() and 'drills' in T('#findResults'), f'{w}: drill search returns drills')
        pg.click('#newSearch'); pg.click('[data-go="1"]'); pg.click('[data-tool="tap"]'); pg.click('#wizNext'); pg.click('#wizNext'); pg.click('#wizNext'); pg.wait_for_timeout(120)
        check('tap' in pg.inner_text('#findResults .rescard >> nth=0').lower(), f'{w}: tap search returns taps')
        pg.click('.rescard .pdp-link >> nth=0'); pg.wait_for_timeout(200); check('thread size' in T('#view-pdp') and 'pitch' in T('#view-pdp') and 'tap drill' in T('#view-pdp'), f'{w}: tap product page (thread specs, pitch feed, tap drill)')
        pg.click('#pdpBack')
        # SKU lookup + recent
        pg.click('#newSearch'); pg.fill('#skuIn','09990840'); pg.press('#skuIn','Enter'); pg.wait_for_timeout(200)
        check('ball end mill' in T('#view-pdp'), f'{w}: SKU lookup opens product page')
        pg.click('#pdpBack'); pg.wait_for_timeout(100); check('09990840' in T('#recentRow'), f'{w}: recent searches row')
        # header search
        pg.fill('#gSearch','09990627'); pg.press('#gSearch','Enter'); pg.wait_for_timeout(200); check('hertel' in T('#view-pdp'), f'{w}: header search opens product page')
        pg.click('#pdpBack')
        # Match
        pg.click('[data-tab="match"]'); pg.click('#matchGo'); pg.wait_for_timeout(200)
        check('your part' in T('#matchOut') and len(pg.query_selector_all('#matchOut .rescard'))==4, f'{w}: reference card + 4 alternatives')
        pg.click('[data-cmp="09990627"]'); pg.fill('#cmpSku','09991420'); pg.evaluate("document.getElementById('cmpForm').requestSubmit()"); pg.wait_for_timeout(200)
        check(T('#matchOut').count('compar')>=1 and ('09991420' in T('#matchOut')), f'{w}: compare + compare another MSC #')
        pg.click('#brandsMatch [data-bb=""]'); pg.click('#brandsMatch [data-bb="Niagara"]'); pg.wait_for_timeout(150); check('niagara' in pg.inner_text('#matchOut .rescard >> nth=0').lower(), f'{w}: brand preference re-ranks Match')
        pg.click('#brandsMatch [data-bb=""]'); pg.click('#brandsMatch [data-bb="Accupro"]'); pg.click('#brandsMatch [data-bb="Hertel"]')
        pg.fill('#matchIn','ABC-123-DEMO'); pg.click('#matchGo'); pg.wait_for_timeout(150); check('recent matches' in T('#matchOut'), f'{w}: recent matches')
        # Crib
        pg.click('[data-tab="crib"]'); check('skus tracked' in T('#cribTbl'), f'{w}: crib summary strip')
        pg.click('#cribRename'); pg.fill('#cribField','Bay 2 — Haas VF-2 (day)'); pg.click('#cribInline button[type=submit]'); pg.wait_for_timeout(100)
        check('(day)' in T('#cribSel'), f'{w}: inline rename (no prompt)')
        pg.click('#cribNew'); pg.fill('#cribField','Bay 3'); pg.click('#cribInline button[type=submit]'); pg.wait_for_timeout(100); check(pg.input_value('#cribSel')=='2', f'{w}: inline new profile')
        pg.click('#cribAdd'); pg.fill('#cribField','12345678'); pg.click('#cribInline button[type=submit]'); pg.wait_for_timeout(100); check('not in the demo catalog' in T('#cribErr'), f'{w}: add SKU validates')
        pg.fill('#cribField','09990233'); pg.click('#cribInline button[type=submit]'); pg.wait_for_timeout(100); check('chamfer' in T('#cribTbl'), f'{w}: add SKU to profile')
        pg.select_option('#cribSel','0'); pg.wait_for_timeout(100); pg.fill('#cribFilter','tap'); pg.wait_for_timeout(100); check('spiral tap' in T('#cribTbl') and 'chamfer' not in T('#cribTbl'), f'{w}: filter box')
        pg.fill('#cribFilter',''); pg.click('#poGo'); pg.wait_for_timeout(100); check('match these on the match tab to include them' in T('#poOut'), f'{w}: PO exclusion note')
        pg.click('#cribTbl [data-pdp] >> nth=0'); pg.wait_for_timeout(150); check(pg.is_visible('#view-pdp') and 'back to crib' in T('#pdpBack'), f'{w}: crib SKU opens product page')
        pg.click('#pdpBack')
        # Library / import
        pg.click('[data-tab="library"]'); check('autodesk inventor' in T('#expFmt') and 'mastercam' not in T('#view-library'), f'{w}: Autodesk-only export targets')
        pg.click('#xmFusion'); pg.wait_for_timeout(150); check('5 of 6 matched' in T('.rollup'), f'{w}: Fusion library import')
        pg.click('#xmOut [data-xp="0|1"]'); pg.wait_for_timeout(100); check('$262.46' in T('.rollup'), f'{w}: roll-up recomputes on alternative flip')
        pg.click('#xmStage'); pg.wait_for_timeout(100); check(int(T('#libBadge'))>=5, f'{w}: stage to library + cart')
        pg.select_option('#expFmt','inventor'); pg.click('#libExport'); pg.wait_for_timeout(100); check('inventor' in T('#toast'), f'{w}: export to Inventor')
        # Cart
        pg.click('[data-tab="cart"]'); check('checkout' in T('#cartExtras') and 'save quote' in T('#cartExtras') and 'crib check' in T('#cartExtras'), f'{w}: cart exits + crib check')
        pg.click('[data-usecrib] >> nth=0'); pg.wait_for_timeout(100)
        pg.click('#cQuote'); pg.wait_for_timeout(100); check('q-2026-0401' in T('#cartExtras'), f'{w}: save quote')
        pg.click('#cOrder'); pg.wait_for_timeout(150); check('order submitted' in T('#cartList') and T('#barCount')=='0 items', f'{w}: checkout confirmation clears cart')
        pg.click('[data-qopen] >> nth=0'); pg.wait_for_timeout(100); check(T('#barCount')!='0 items', f'{w}: reopen quote into cart')
        check(not errs, f'{w}: no console/page errors {errs[:3]}')
        pg.close()
    b.close()
print('\n%d failures' % len(fails)); sys.exit(1 if fails else 0)
